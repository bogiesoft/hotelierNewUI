<?php
/*
-----------------
Hotel Configuration File
-----------------
*/

$pref = array();

$pref['PROPERTY_NAME'] = 'Título de la página de mi sitio web';
$pref['PROPERTYID'] = '8';